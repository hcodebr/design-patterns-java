package br.com.hcode.solid.ocp;

public enum TypeVehicle {
    CAR,
    MOTORCYCLE
}
