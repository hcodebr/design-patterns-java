package br.com.hcode.adapter.utils;

public class Token {
    private String token;

    public Token(){
        this.token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkRlc2lnbiBQYXR0ZXJucyIsImlhdCI6MTUxNjIzOTAyMn0.Ci3--TbmVnrlM-q8KYaVJwj_QM6tGbeN2R79IxuT0ds";
    }

    public String getToken() {
        return token;
    }
}
