package br.com.hcode.bridge.transmissions;

public interface ITransmission {
    void broadcasting();
    void result();
}
