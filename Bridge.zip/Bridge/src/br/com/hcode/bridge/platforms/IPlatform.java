package br.com.hcode.bridge.platforms;

public interface IPlatform {
    void configureRMTP();
    void authToken();
}
