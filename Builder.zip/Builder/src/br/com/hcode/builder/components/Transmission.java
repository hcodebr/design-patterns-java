package br.com.hcode.builder.components;

public enum Transmission {
    MANUAL, AUTOMATIC, AUTOMATIC_SEQUENTIAL
}
