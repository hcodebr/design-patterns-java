package br.com.hcode.builder.components;

public enum CarType {
    SEDAN, SPORTCAR, SUV, PICKUPTRUCK, TRUCK
}
