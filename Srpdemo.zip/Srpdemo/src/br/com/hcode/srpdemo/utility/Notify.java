package br.com.hcode.srpdemo.utility;

public class Notify {

    public void notifyClient(){

    }
}
