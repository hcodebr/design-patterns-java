package br.com.hcode.srpdemo;

public class Main {

    public static void main(String[] args) {

    }

    public void listClient(){

    }
    public void addClient(){

    }
    public void updateClient(){

    }
    public void deleteClient(){

    }


}
