package br.com.hcode.solid.isp.vehicles;

public interface IVehicleMotorcycle {
    public void configureMotorcycle(String color, String year, double engine);
}
