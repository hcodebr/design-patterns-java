package br.com.hcode.solid.isp.vehicles;

public interface IVehicle {


    public void startVehicle();
}


