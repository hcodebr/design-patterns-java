package br.com.hcode.solid.isp.vehicles;

public interface IVehicleCar {
    public void configureCar(String color, String year, double engine, int seats);
}
