package br.com.hcode.solid.dip.model;

public enum Db {
    MYSQL,
    MONGODB,
    SQLSERVER,
    ORACLE,
    POSTGRESQL
}
