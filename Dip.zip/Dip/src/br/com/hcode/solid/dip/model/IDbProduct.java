package br.com.hcode.solid.dip.model;

public interface IDbProduct {
    public String getProductById(String productID);
}
