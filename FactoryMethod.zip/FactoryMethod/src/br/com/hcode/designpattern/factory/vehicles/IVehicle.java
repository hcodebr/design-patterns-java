package br.com.hcode.designpattern.factory.vehicles;

public interface IVehicle {

    void startRoute();
    void getCargo();
}
