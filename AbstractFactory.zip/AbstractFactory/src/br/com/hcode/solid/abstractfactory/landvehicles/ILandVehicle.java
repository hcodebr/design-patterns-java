package br.com.hcode.solid.abstractfactory.landvehicles;

public interface ILandVehicle {
    void startRoute();
    void getCargo();
}
