package br.com.hcode.solid.abstractfactory.boats;

public interface IBoat {
    void startRoute();
    void getCargo();
}
