package br.com.hcode.solid.abstractfactory.aircrafts;

public interface IAircraft {
    void startRoute();
    void getCargo();
    void wind();
}
